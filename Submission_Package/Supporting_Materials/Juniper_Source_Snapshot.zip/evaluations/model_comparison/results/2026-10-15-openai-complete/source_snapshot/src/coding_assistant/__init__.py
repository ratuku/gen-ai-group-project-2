"""Autonomous CLI coding assistant."""
